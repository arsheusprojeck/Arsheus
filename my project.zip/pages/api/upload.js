// api/upload.js
import { createClient } from '@supabase/supabase-js';
import formidable from 'formidable';
import fs from 'fs';
import path from 'path';

export const config = {
  api: { bodyParser: false } // penting: biar formidable yg handle multipart
};

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY // pakai anon public key
);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // parse form-data (name + file)
    const { fields, files } = await new Promise((resolve, reject) => {
      const form = formidable({ multiples: false, maxFiles: 1 });
      form.parse(req, (err, fields, files) => {
        if (err) reject(err);
        else resolve({ fields, files });
      });
    });

    const name = (fields.name || fields.nama || 'Tanpa Nama').toString();

    // ambil file
    let f = files.file || files.bukti; // dukung "file" atau "bukti"
    if (Array.isArray(f)) f = f[0];
    if (!f) return res.status(400).json({ error: 'File tidak ditemukan' });

    const ext = path.extname(f.originalFilename || '') || '.png';
    const objectName = `bukti_${Date.now()}${ext}`;
    const fileBuffer = fs.readFileSync(f.filepath);
    const contentType = f.mimetype || 'image/png';

    // upload ke bucket "pembayaran" (harus dibuat & diset public)
    const { error: upErr } = await supabase
      .storage
      .from('pembayaran')
      .upload(objectName, fileBuffer, {
        contentType,
        cacheControl: '3600',
        upsert: false
      });

    if (upErr) {
      return res.status(500).json({ error: `Upload gagal: ${upErr.message}` });
    }

    // ambil public URL
    const { data: pub } = supabase
      .storage
      .from('pembayaran')
      .getPublicUrl(objectName);

    return res.status(200).json({
      message: 'Upload berhasil',
      name,
      url: pub.publicUrl
    });
  } catch (e) {
    return res.status(500).json({ error: `Server error: ${e.message}` });
  }
}